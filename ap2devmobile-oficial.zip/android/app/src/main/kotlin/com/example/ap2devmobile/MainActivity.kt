package com.example.ap2devmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
